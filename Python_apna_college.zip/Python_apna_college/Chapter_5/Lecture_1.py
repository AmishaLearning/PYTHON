print("------------------------------Loops------------------------------")
# print("\n")
# print("------------------------------While Loops------------------------------")

# for i in range(0, 6):
#  print("Hello!!")
 
# i = 0
# while i < 5:
#     print("Goodbye!!")
#     i += 1
# print(i)

# # print numbers for 1 to 5

# i = 1
# while i <=5:
#     print(i)
#     i += 1
# print("Loop Ended")

# i = 5
# while i >= 1 :
#     print(i)
#     i -= 1 
# print("Loop Ended")   

# print("---------------------------Break/Continue------------------------")

# nums = [1, 4, 9, 16, 25, 36, 49, 64, 81, 100]
# x = 36

# i = 0
# while i < len(nums):
#     if (nums[i] == x):
#         print("Found at inded : ", i)
#         break
#     else:
#         print("Finding")
#         i += 1
        
# i = 0
# while i <= 5:
#     if (i == 3):
#         i += 1
#         continue # skips everthing after this if i == 3
#     print(i)
#     i += 1

# print("--------------------------------For Loops--------------------------------")

# list1 = [1, 3, 5, 4, 7, 9]

# for i in list1:
#     print(i)    
    
# veggies = ["potato", "tomato", "bringle", "cucumber"]

# for vegetables in veggies :
#     print(vegetables)
# else:
#     print("No more vegetables")

# Else will not work with break 
# str1 = "apnacollege"

# for char in str1:
#     if (char == 'o'):
#         print("Found O")
#         break
#     print(char)
# else:
#     print("No more o")    
    

# str1 = "apnacollege"

# for char in str1:
#     if (char == 'o'):
#         print("Found O")
#         break
#     print(char)
# print("No more o")    

# print("-----------------------------Range--------------------------------")

# for el in range(5):
#     print(el)
    
# for el in range(1, 5):
#     print(el)
    
# for el in range(1, 5, 2):
#     print(el)
    
print("-----------------------------Pass--------------------------------")
for i in range(5):
    #empty
    pass 
    
print("Sone Useful Work")