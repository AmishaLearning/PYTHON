# print("---------------------------------")
# print("Hello World") 

# print("---------------------------------")
# print("Amisha is my name.", "My age is 26")
# print(23)
# print(35 + 20 )

# print("----------------Variables-----------------")
# name = "Amisha"
# age = 26
# price = 26.99
# age2 = age
# print("My name is :", name)
# print("My age is :", age)
# print("Age2 :",age2) 
 
# print("---------------Type------------------")
# print(type(name))
# print(type(age))
# print(type(price))

# print("----------------Strings-----------------")
# name1 = "AS"
# name2 = 'AS'
# name3 = '''AS'''
# print(name1, name2, name3)

# print("----------------Bool/None-----------------")
# age = 23
# old = False
# a = None
# print(type(old))
# print(type(a))

# print("-----------------SUM/DIFFerence----------------")
# a = 5
# b = 8
# sum = a + b
# diff = a - b
# print("Sum :", sum)
# print("Difference :",diff)

# print("-----------------Expression Execution----------------")
# A, B = 2, 3
# Txt = "@"
# print(2 * Txt * 3)

# A, B = "2", 3
# Txt = "@"
# print((A + Txt) * B) # Two strings added : Concatenation

# A, B = 2, 3
# C = 4
# print(A + B * C)

# A, B = 10, 5.0
# C = A * B
# print(C)

# A, B = 1, 2
# C = A / B
# print(C)

# A, B = 1.5, 3
# C = A // B
# print(C, A/B) 

# print("----------------FLOOR Division-----------------")

# A, B = 12, 5
# print(A // B)

# A, B = -12, 5
# print(A // B)

# A, B = 12, -5
# print(A // B)

# print("----------------Modulo-----------------")

# A, B = -5, 2
# print(A % B)

# A, B = 5, 2
# print(A % B)

# A, B = 5, -2
# print(A % B)

# print("------------------Input in Python---------------")

# name = input("Name : ")
# age = int(input("Age :"))
# print("My name is", name, "and I am", age, "years old.")

# price = float(input("Price :"))
# print(price)

print(not True and False or True)
