print("---------------------Practice_1-------------------------------")

# print("---------------------Question_1-------------------------------")
# num1 = float(input("Enter First Number : "))
# num2 = float(input("Enter Second Number : "))

# sum = num1 + num2
# print("Rhe sum is : ", sum)

# print("---------------------Question_2-------------------------------")
# side = int(input("Enter side of a square : "))
# area = side ** 2
# print("The area of the square is :", side ** 2)

# print("---------------------Question_3-------------------------------")
# num1 = float(input("Enter First Number : "))
# num2 = float(input("Enter Second Number : "))
# avearge = (num1 + num2)/ 2
# print("The average is :",avearge)

# print("------------------------Question_4-----------------------")
# num1 = float(input("Enter first number : " ))
# num2 = float(input("Enter second number : " ))
# if num1 >= num2:
#     print(True)
# else:
#     print(False)