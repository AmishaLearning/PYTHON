# print("-----------------Conditional Statements----------------")

# light = input("Color : ")

# if (light == "Red" or light == "red"):
#     print("Stop")
# elif (light == "Yellow" or light == "yellow"):
#     print("Look")
# elif (light == "Green" or light == "green"):
#     print("Go")
# else:
#     print("Light is broken")
 
# print("-----------------Conditional Statements Boolean----------------")

# A = int(input("A : "))
# G = input("M/F : ")

# if((A == 1 or A == 2) and G == "M"):
#     print("Fee is 100")
# elif ((A == 3 or A == 4 or G == "F")):
#     print("Fee is 200")
# elif (A == 5 and G == "M"):
#     print("Fee is 300")
# else:
#     print("No Fee")   
   
# print("-----------------Conditional Statements Single Line----------------")

# food = input("Food : ")
# eat = "Yes" if food == "cake" else "no"
# print(eat) 

# food = input("Food : ")
# print("Sweet") if food == "cake" or food == "jalebi" else print ("Not Sweet")

# print("-----------------Clever If----------------")

# age = int(input("A : "))
# status = ("Not Eligible for DL", "Eligible for DL") [age >= 18]
# print(status)

# salary = float(input("Salary : "))
# tax = salary * (0.1, 0.2) [salary >= 50000]
# print(tax)

# print("-----------------Type of Operators----------------")
# print("-----------------Arithematic Operators----------------")

# a = 10
# b = 3

# print("Addition : ", a + b)
# print("Subtraction : ", a - b)
# print("Multipliplication : ", a * b)
# print("Division : ", a / b)  # always a floating value
# print("Remainder : ", a % b)
# print("Power : ", a ** b)

# print("--------------------------Relational/Comparsion Operators----------------------------")

# a = 11
# b = 20

# print("A is equal to B                 : ", [a == b])
# print("A is not Equal to B             : ", [a != b])
# print("A is greater than B             : ", [a > b])
# print("A is less than B                : ", [a < b])
# print("A is greater than or equal to B : ", [a >= b])
# print("A is less than or equal to B    : ", [a <= b])

# print("--------------------------Assignment Operators----------------------------")

# num = 10
# num += 5
# print("num = ", num)
# num -= 5
# print("num = ", num)
# num *= 4
# print("num = ", num)
# num /= 2
# print("num = ", num)
# num %= 3
# print("num = ", num)
# num **= 5
# print("num = ", num)

# print("--------------------------Boolean Operators----------------------------")

# val1 = True
# val2 = False

# print("not val1 : ", not val1)
# print("val1 and val2 : ", val1 and val2)
# print("val1 or val2 : ", val1 or val2)

# print("---------------------------Type Coversion---------------------------")

# num1 = 5
# num2 = 2.6
# print("Sum : ", num1 + num2)

# print("---------------------------Type Casting---------------------------")

# num1 = "2"
# num2 = 3.2
# print("Sum : ", int(num1) + num2)

