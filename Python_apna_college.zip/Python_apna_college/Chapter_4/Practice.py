print("---------------------------Practice_4------------------------\n")

# print("---------------------------Question_1------------------------\n")

# dict1 = {"table" : ["a piece of furniture", "list of facts & figures"], "cat" : "a small animal"}
# print(dict1)
# print("\n")

# print("---------------------------Question_2------------------------\n")

# classroom = {"python", "java", "C++", "python", "javascript", "java", "python", "java", "C++", "C"}

# print("No. of classrooms required", len(classroom))

# print("---------------------------Question_3------------------------\n")

# subject_marks = {}
# for i in range(1, 4):
#     subject_name = input(f"Enter subject number {i} : ".format(i))
#     marks = int(input(f"Enter marks for subject {i} : ".format(i)))
#     subject_marks[subject_name] = marks
# print(subject_marks)

# marks = {}
# maths = int(input("Enter marks for Maths : "))
# marks.update({"Maths" : maths})
# physics = int(input("Enter marks for Physics : "))
# marks.update({"Physics" : maths})
# chemistry = int(input("Enter marks for Chemistry : "))
# marks.update({"Chemistry" : maths})

# print(marks)

# print("---------------------------Question_4------------------------\n")

# set1 = set()
# set1.add(9)
# set1.add("9.0")
# print(set1)

# set2 = {
#     ('float', 9.0),
#     ("int", 9)
# }
# print(set2)
