# print("----------------------List----------------------")

# marks =[65.5, 87.9, 45.7, 78.3, 65.2]
# print(marks)
# print(type(marks))
# print(marks[0])
# print(len(marks))

# student=["Karan", 67, "Delhi"]
# print(student)

# print("-----------------------Mutability---------------------")
# student = ["Arjun", 89, "Delhi"]
# student[2] = "Bangalore"
# print(student)

# print("-----------------------Slicing---------------------")
# marks = [12, 23, 34, 45, 56, 67, 78, 89]
# print(marks[0:4])
# print(marks[:5])
# print(marks[-5:])

# print("-----------------------Methods---------------------")
# list1 = [98, 87, 76, 65, 54, 43, 32, 21]
# list1.append(3) # mutation
# print(list1)
# list1.sort()
# print(list1)
# list1.sort(reverse=True)
# print(list1)

# list2 = ["Banana", "Apple", "Orange", "Lichi"]
# list2.sort()
# print(list2)
# list3 = ["d", "a", "e", "f", "b", "g", "c"]
# list3.sort()
# print(list3)
# list3.reverse()
# print(list3)
# list3.insert(1, "Pineapple")
# print(list3)

# list4 = ["banana", "apple", "orange", "kiwi", "banana", "watermelon", "banana"]
# list4.remove("banana")
# print(list4)

# list4.pop(4)
# print(list4)

# print("---------------------------Tuples------------------------")
# tuple1 = (3, 5, 7, 9, 11)
# print(tuple1[2])

# tuple2 = ()
# print(tuple2)
# print(type(tuple2))

# print("---------------------------Single Value Tuple------------------------")
# tuple1 = (1,)
# print(type(tuple1))
# tuple2 = (4)
# print(type(tuple2))

# print("---------------------------Slicing------------------------")
# tup = (3, 2, 5, 6)
# print(tup[1:4])

# print("---------------------------Methods------------------------")
# tup = (3, 4, 6, 3, 7, 8, 3)
# print(tup.index(6))
# print(tup.count(3))