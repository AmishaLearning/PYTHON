
print("---------------------Practice_3-------------------------------")

print("---------------------Question_1-------------------------------")
# WAP to ask the user to enter names of their 3 favourite movies & store them in list.

# movies = int(input("Enter the number of Movies : "))
# fav_movies = []
# for i in range(1, movies + 1 ):
#     movie_name = input(f"Enter Movie {i} : ")
#     fav_movies.append(movie_name)
# print(fav_movies)
    
# movies = []
# movies.append(input("Enter the 1st movie : "))
# movies.append(input("Enter the 2nd movie : "))
# movies.append(input("Enter the 3rd movie : "))
# print(movies)

print("---------------------Question_2-------------------------------")

# WAP to check if list contains a palingrome of elements, use copy() methods

# list1 = [1, "abc", "abc", 1]
# list2 = list1.copy()

# list2.reverse()
# if list1 == list2:
#     print("list1", list1)
#     print("list2", list2)
#     print("Palindrome")
# else:
    
#     print("Not a Palindrome")

print("---------------------Question_3-------------------------------")

# WAP to count the number of students with "A" grade in following tuple

# tup1 = ("C", "D", "A", "A", "B", "B", "A")
# print(tup1.count("A"))

# Store above value in list and sort them from "A" to "D"
# list1 = list(tup1)
# list1.sort()
# print(list1)
