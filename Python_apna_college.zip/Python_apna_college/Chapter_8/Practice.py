# print("--------------------------------Question_1--------------------------------")

# class Student:
#     def __init__(self, name, marks1, marks2, marks3):
#         self.name = name
#         self.marks1 = marks1
#         self.marks2 = marks2
#         self.marks3 = marks3
        
#     def marks_average(self):
#         sum = self.marks1 + self.marks2 + self.marks3
#         print("Hi", self.name, "Your Average score is :", sum/3)

# s1 = Student("Arjun", 99, 98, 97)
# s1.marks_average()

# s2 = Student("Karan", 96, 95, 94)
# s2.marks_average()

# print("---------------------------------Question_2--------------------------------")

# class Account:
#     def __init__(self, account_no, balance):
#         self.account = account_no
#         self.balance = balance
        
#     def debit(self, amount):
#         self.balance -= amount
#         print("Rs.", amount, "was debited from account")
#         print("Amount Remaining :", self.get_balance())
        
#     def credit(self, amount):
#         self.balance += amount
#         print("Rs.", amount, "was credited to account")   
#         print("Amount Remaining :", self.get_balance())
        
#     def get_balance(self):
#         return self.balance
    
# acc1 = Account(567845, 10000)
# print(acc1.balance, acc1.account)
# acc1.debit(5000)
# acc1.credit(2000)



