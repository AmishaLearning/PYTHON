# del Keyword 

# class Student:
#     def __init__(self, name):
#         self.name = name
        
# s1 = Student("Amisha")
# print(s1.name)
# del s1.name
# print(s1.name)

# print("------------------------Private/Public Attributes----------------")

# Private and Public attributes

# class Account:
#     def __init__(self, acc_no, acc_pass):
#         self.acc_no = acc_no
#         self.__acc_pass = acc_pass
    
#     # we are able to access the private attribute here because this function is inside the class
#     def reset_pass(self):
#         print(self.__acc_pass)
        
# acc1 = Account(654321, "password")
# acc1.reset_pass()
# print(acc1.acc_no, acc1.__acc_pass)

# class Person:
#     __name = "Anonymous"
    
#     def __hello(self): # Private function
#         print("Hello Person")
        
#     def welcome(self):
#         self.__hello()
        
# p1 = Person()
# # print(p1.__name)
# p1.welcome()

print("-----------------------------------Inheritance--------------------------------")

class Car:
    color = "Black"
    @staticmethod
    def start():
        print("Car Started")
    
    @staticmethod
    def stop():
        print("Car Stopped")
        
class ToyotaCar(Car):
    def __init__(self, name):
        self.name = name

car1 = ToyotaCar("Fortuner")
car2 = ToyotaCar("Prius")    

print(car1.name)
print(car2.name)  
car1.start()
print(car1.color)
        
    