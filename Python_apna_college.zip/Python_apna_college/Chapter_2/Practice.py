print("---------------------Practice_2-------------------------------")

# print("--------------------------Question_1------------------------------")
# name = input("Enter a name : ")
# print("The length is : ", len(name))

# print("--------------------------Question_2------------------------------")
# string = "$ Today $ is $ 9th $ April $ 2024 $"
# print(string.count("$"))

# print("---------------------------Question_3------------------------------")

# number = int(input("Enter a Number : "))
# if (number % 2 == 0):
#     print("Even Number")
# else:
#     print("Odd Number")
    
# print("---------------------------Question_4------------------------------")

# num1 = float(input("Enter first number : "))
# num2 = float(input("Enter second number : "))
# num3 = float(input("Enter third number :" ))

# if (num1 > num2) and (num1 > num3):
#     print(f"The greatest number among {num1}, {num2}, {num3} is {num1}")
# elif (num2 > num1) and (num2 > num3):
#     print(f"The greatest number among {num1}, {num2}, {num3} is {num2}")
# else:
#     print(f"The greatest number among {num1}, {num2}, {num3} is {num3}")

# print("--------------------------------Question_5--------------------------------")

# number = int(input("Entaer a Number : "))

# if (number % 7 == 0):
#     print(f"{number} is a multiple of 7")
# else:
#     print(f"{number} is not a multiple of 7")